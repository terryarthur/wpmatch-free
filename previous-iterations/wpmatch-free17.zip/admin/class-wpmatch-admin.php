<?php
/**
 * Admin interface for WP Match Free
 *
 * @package WPMatchFree
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin interface for WP Match Free
 *
 * Manages the WordPress admin interface for the dating plugin,
 * including profile field management, dashboard statistics, and settings.
 *
 * @package WPMatchFree
 * @since   1.0.0
 */
class WPMatch_Admin {
	/**
	 * AJAX: Render field list HTML for partial reload
	 */
	public function ajax_render_field_list() {
		check_ajax_referer( 'wpmatch_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}
		global $wpdb;
		$fields = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wpmatch_profile_fields ORDER BY display_order ASC" );
		ob_start();
		?>
		<div class="field-content">
		<?php foreach ( $this->get_field_groups() as $group_id => $group_label ) : ?>
			<div class="tab-content" id="tab-<?php echo esc_attr( $group_id ); ?>" <?php echo 'basic' !== $group_id ? 'style="display:none"' : ''; ?>>
				<div class="fields-header">
					<h2><?php echo esc_html( $group_label ); ?></h2>
					<button class="button button-primary add-field-btn" data-group="<?php echo esc_attr( $group_id ); ?>">
						<?php esc_html_e( 'Add Field', 'wpmatch-free' ); ?>
					</button>
				</div>
				<div class="sortable-fields" data-group="<?php echo esc_attr( $group_id ); ?>">
					<?php
					$group_fields = array_filter(
						$fields,
						function ( $field ) use ( $group_id ) {
							return $field->field_group === $group_id;
						}
					);
					foreach ( $group_fields as $field ) :
					?>
						<div class="field-row" data-field-id="<?php echo esc_attr( $field->field_id ); ?>">
							<div class="field-handle">
								<span class="dashicons dashicons-move"></span>
							</div>
							<div class="field-info">
								<strong><?php echo esc_html( $field->field_label ); ?></strong>
								<span class="field-type">(<?php echo esc_html( $field->field_type ); ?>)</span>
								<div class="field-meta">
									<?php if ( $field->is_required ) : ?>
										<span class="required-badge"><?php esc_html_e( 'Required', 'wpmatch-free' ); ?></span>
									<?php endif; ?>
									<?php if ( $field->searchable ) : ?>
										<span class="searchable-badge"><?php esc_html_e( 'Searchable', 'wpmatch-free' ); ?></span>
									<?php endif; ?>
								</div>
							</div>
							<div class="field-actions">
								<button class="button edit-field" data-field-id="<?php echo esc_attr( $field->field_id ); ?>">
									<?php esc_html_e( 'Edit', 'wpmatch-free' ); ?>
								</button>
								<button class="button delete-field" data-field-id="<?php echo esc_attr( $field->field_id ); ?>">
									<?php esc_html_e( 'Delete', 'wpmatch-free' ); ?>
								</button>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endforeach; ?>
		</div>
		<?php
		$html = ob_get_clean();
		wp_send_json_success( $html );
	}

	/**
	 * Initialize admin functionality
	 *
	 * Sets up WordPress hooks for admin menu, scripts, and AJAX handlers.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'wp_ajax_wpmatch_save_field', array( $this, 'ajax_save_field' ) );
		add_action( 'wp_ajax_wpmatch_delete_field', array( $this, 'ajax_delete_field' ) );
	add_action( 'wp_ajax_wpmatch_reorder_fields', array( $this, 'ajax_reorder_fields' ) );
	add_action( 'wp_ajax_wpmatch_render_field_list', array( $this, 'ajax_render_field_list' ) );
}

	/**
	 * Add admin menu items
	 *
	 * @since 1.0.0
	 */
	public function add_admin_menu() {
		// Main menu page
		add_menu_page(
			'WP Match Free',
			'WP Match Free',
			'manage_options',
			'wpmatch-free',
			array( $this, 'render_dashboard_page' ),
			'dashicons-heart',
			30
		);

		// Dashboard submenu (first item matches parent)
		add_submenu_page(
			'wpmatch-free',
			__( 'Dashboard', 'wpmatch-free' ),
			__( 'Dashboard', 'wpmatch-free' ),
			'manage_options',
			'wpmatch-free',
			array( $this, 'render_dashboard_page' )
		);

		// Profile Fields submenu
		add_submenu_page(
			'wpmatch-free',
			__( 'Profile Fields', 'wpmatch-free' ),
			__( 'Profile Fields', 'wpmatch-free' ),
			'manage_options',
			'wpmatch-fields',
			array( $this, 'render_fields_page' )
		);

		// Settings submenu
		add_submenu_page(
			'wpmatch-free',
			__( 'Settings', 'wpmatch-free' ),
			__( 'Settings', 'wpmatch-free' ),
			'manage_options',
			'wpmatch-settings',
			array( $this, 'render_settings_page' )
		);

		// Demo Content submenu
		add_submenu_page(
			'wpmatch-free',
			__( 'Demo Content', 'wpmatch-free' ),
			__( 'Demo Content', 'wpmatch-free' ),
			'manage_options',
			'wpmatch-demo',
			array( $this, 'render_demo_page' )
		);
	}

	/**
	 * Enqueue admin scripts and styles
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_scripts( $hook ) {
		if ( strpos( $hook, 'wpmatch' ) === false ) {
			return;
		}

		// Admin CSS.
		wp_enqueue_style(
			'wpmatch-admin-css',
			WPMATCH_URL . 'assets/admin.css',
			array(),
			WPMATCH_VERSION
		);

		// Admin JavaScript.
		wp_enqueue_script(
			'wpmatch-admin-js',
			WPMATCH_URL . 'assets/admin.js',
			array( 'jquery' ),
			WPMATCH_VERSION,
			true
		);

		// Localize script for AJAX URL and nonce.
		wp_localize_script(
			'wpmatch-admin-js',
			'wpmatch_admin',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'wpmatch_admin_nonce' ),
			)
		);
	}

	/**
	 * Render performance page
	 */
	public function render_performance_page() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Performance', 'wpmatch-free' ) . '</h1><p>' . esc_html__( 'Performance stats and optimization tools will appear here.', 'wpmatch-free' ) . '</p></div>';
	}

	/**
	 * Render reports page
	 */
	public function render_reports_page() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Reports', 'wpmatch-free' ) . '</h1><p>' . esc_html__( 'Reports and analytics will appear here.', 'wpmatch-free' ) . '</p></div>';
	}

	/**
	 * Render photos page
	 */
	public function render_photos_page() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Photos', 'wpmatch-free' ) . '</h1><p>' . esc_html__( 'Photo moderation and management will appear here.', 'wpmatch-free' ) . '</p></div>';
	}

	/**
	 * Render verifications page
	 */
	public function render_verifications_page() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Verifications', 'wpmatch-free' ) . '</h1><p>' . esc_html__( 'User verification management will appear here.', 'wpmatch-free' ) . '</p></div>';
	}
	/**
	 * Render dashboard page
	 *
	 * @since 1.0.0
	 */
	public function render_dashboard_page() {
		global $wpdb;

		// Get statistics.
		$stats = array(
			'total_profiles' => $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users}" ),
			'active_fields'  => $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}wpmatch_profile_fields" ),
			'total_messages' => 0, // Will implement later.
			'matches_made'   => 0, // Will implement later.
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'WP Match Free Dashboard', 'wpmatch-free' ); ?></h1>
			
			<div class="wpmatch-dashboard-stats">
				<div class="stat-box">
					<h3><?php echo number_format( $stats['total_profiles'] ); ?></h3>
					<p><?php esc_html_e( 'Total Profiles', 'wpmatch-free' ); ?></p>
				</div>
				<div class="stat-box">
					<h3><?php echo number_format( $stats['active_fields'] ); ?></h3>
					<p><?php esc_html_e( 'Profile Fields', 'wpmatch-free' ); ?></p>
				</div>
				<div class="stat-box">
					<h3><?php echo number_format( $stats['total_messages'] ); ?></h3>
					<p><?php esc_html_e( 'Messages Sent', 'wpmatch-free' ); ?></p>
				</div>
				<div class="stat-box">
					<h3><?php echo number_format( $stats['matches_made'] ); ?></h3>
					<p><?php esc_html_e( 'Matches Made', 'wpmatch-free' ); ?></p>
				</div>
			</div>

			<div class="wpmatch-quick-actions">
				<h2><?php esc_html_e( 'Quick Actions', 'wpmatch-free' ); ?></h2>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wpmatch-fields' ) ); ?>" class="button button-primary">
					<?php esc_html_e( 'Manage Profile Fields', 'wpmatch-free' ); ?>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=wpmatch-settings' ) ); ?>" class="button">
					<?php esc_html_e( 'Plugin Settings', 'wpmatch-free' ); ?>
				</a>
			</div>
		</div>
		<?php
	}

	/**
	 * Render profile fields management page
	 *
	 * @since 1.0.0
	 */
	public function render_fields_page() {
		global $wpdb;

		// Get existing fields.
		$fields = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wpmatch_profile_fields ORDER BY display_order ASC" );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Profile Fields Management', 'wpmatch-free' ); ?></h1>
			
			<div class="wpmatch-field-manager">
				<div class="field-tabs">
					<button class="tab-button active" data-tab="basic"><?php esc_html_e( 'Basic Identity', 'wpmatch-free' ); ?></button>
					<button class="tab-button" data-tab="location"><?php esc_html_e( 'Location', 'wpmatch-free' ); ?></button>
					<button class="tab-button" data-tab="appearance"><?php esc_html_e( 'Appearance', 'wpmatch-free' ); ?></button>
					<button class="tab-button" data-tab="lifestyle"><?php esc_html_e( 'Lifestyle', 'wpmatch-free' ); ?></button>
					<button class="tab-button" data-tab="interests"><?php esc_html_e( 'Interests', 'wpmatch-free' ); ?></button>
				</div>

				<div class="field-content">
					<?php foreach ( $this->get_field_groups() as $group_id => $group_label ) : ?>
						<div class="tab-content" id="tab-<?php echo esc_attr( $group_id ); ?>" <?php echo 'basic' !== $group_id ? 'style="display:none"' : ''; ?>>
							<div class="fields-header">
								<h2><?php echo esc_html( $group_label ); ?></h2>
								<button class="button button-primary add-field-btn" data-group="<?php echo esc_attr( $group_id ); ?>">
									<?php esc_html_e( 'Add Field', 'wpmatch-free' ); ?>
								</button>
							</div>
							
							<div class="sortable-fields" data-group="<?php echo esc_attr( $group_id ); ?>">
								<?php
								$group_fields = array_filter(
									$fields,
									function ( $field ) use ( $group_id ) {
										return $field->field_group === $group_id;
									}
								);

								foreach ( $group_fields as $field ) :
									?>
									<div class="field-row" data-field-id="<?php echo esc_attr( $field->field_id ); ?>">
										<div class="field-handle">
											<span class="dashicons dashicons-move"></span>
										</div>
										<div class="field-info">
											<strong><?php echo esc_html( $field->field_label ); ?></strong>
											<span class="field-type">(<?php echo esc_html( $field->field_type ); ?>)</span>
											<div class="field-meta">
												<?php if ( $field->is_required ) : ?>
														<span class="required-badge"><?php esc_html_e( 'Required', 'wpmatch-free' ); ?></span>
												<?php endif; ?>
												<?php if ( $field->searchable ) : ?>
													<span class="searchable-badge"><?php esc_html_e( 'Searchable', 'wpmatch-free' ); ?></span>
												<?php endif; ?>
											</div>
										</div>
										<div class="field-actions">
											<button class="button edit-field" data-field-id="<?php echo esc_attr( $field->field_id ); ?>">
												<?php esc_html_e( 'Edit', 'wpmatch-free' ); ?>
											</button>
											<button class="button delete-field" data-field-id="<?php echo esc_attr( $field->field_id ); ?>">
												<?php esc_html_e( 'Delete', 'wpmatch-free' ); ?>
											</button>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>

		<!-- Field Editor Modal -->
		<div id="field-editor-modal" class="wpmatch-modal" style="display:none;">
			<div class="modal-content">
				<div class="modal-header">
					<h2 id="modal-title"><?php esc_html_e( 'Add Field', 'wpmatch-free' ); ?></h2>
					<button class="modal-close">&times;</button>
				</div>
				<div class="modal-body">
					<form id="field-form">
						<input type="hidden" id="field-id" name="field_id">
						<input type="hidden" id="field-group" name="field_group">
						
						<table class="form-table">
							<tr>
								<th><label for="field_key"><?php esc_html_e( 'Field Key', 'wpmatch-free' ); ?></label></th>
								<td>
									<input type="text" id="field_key" name="field_key" class="regular-text" required>
									<p class="description"><?php esc_html_e( 'Machine-readable name (letters, numbers, underscores only)', 'wpmatch-free' ); ?></p>
								</td>
							</tr>
							<tr>
								<th><label for="field_label"><?php esc_html_e( 'Field Label', 'wpmatch-free' ); ?></label></th>
								<td>
									<input type="text" id="field_label" name="field_label" class="regular-text" required>
								</td>
							</tr>
							<tr>
								<th><label for="field_type"><?php esc_html_e( 'Field Type', 'wpmatch-free' ); ?></label></th>
								<td>
									<select id="field_type" name="field_type" required>
										<option value="text"><?php esc_html_e( 'Text', 'wpmatch-free' ); ?></option>
										<option value="textarea"><?php esc_html_e( 'Text Area', 'wpmatch-free' ); ?></option>
										<option value="select"><?php esc_html_e( 'Dropdown', 'wpmatch-free' ); ?></option>
										<option value="multiselect"><?php esc_html_e( 'Multi-Select', 'wpmatch-free' ); ?></option>
										<option value="date"><?php esc_html_e( 'Date', 'wpmatch-free' ); ?></option>
										<option value="location"><?php esc_html_e( 'Location', 'wpmatch-free' ); ?></option>
										<option value="image"><?php esc_html_e( 'Image Upload', 'wpmatch-free' ); ?></option>
									</select>
								</td>
							</tr>
							<tr id="options-row" style="display:none;">
								<th><label for="field_options"><?php esc_html_e( 'Options', 'wpmatch-free' ); ?></label></th>
								<td>
									<div id="options-container">
										<!-- Options will be added dynamically -->
									</div>
									<button type="button" id="add-option" class="button"><?php esc_html_e( 'Add Option', 'wpmatch-free' ); ?></button>
								</td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Field Settings', 'wpmatch-free' ); ?></th>
								<td>
									<label>
										<input type="checkbox" id="is_required" name="is_required" value="1">
										<?php esc_html_e( 'Required field', 'wpmatch-free' ); ?>
									</label><br>
									<label>
										<input type="checkbox" id="searchable" name="searchable" value="1">
										<?php esc_html_e( 'Searchable field', 'wpmatch-free' ); ?>
									</label>
								</td>
							</tr>
						</table>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="button" id="cancel-field"><?php esc_html_e( 'Cancel', 'wpmatch-free' ); ?></button>
					<button type="button" class="button button-primary" id="save-field"><?php esc_html_e( 'Save Field', 'wpmatch-free' ); ?></button>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render settings page
	 *
	 * @since 1.0.0
	 */
	public function register_settings() {
		register_setting(
			'wpmatch_settings',
			'wpmatch_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_settings' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type'       => 'array',
						'items'      => array(
							'type'       => 'object',
							'properties' => array(
								'profile_visibility' => array(
									'type' => 'string',
								),
								'new_user_approval' => array(
									'type' => 'string',
								),
							),
						),
						'default'    => array(
							array(
								'profile_visibility' => 'public',
								'new_user_approval'  => 'no',
							),
						),
					),
				),
				'default'           => array(
					array(
						'profile_visibility' => 'public',
						'new_user_approval'  => 'no',
					),
				),
			)
		);

		add_settings_section(
			'wpmatch_main',
			__( 'Main Settings', 'wpmatch-free' ),
			array( $this, 'render_settings_section' ),
			'wpmatch-settings'
		);

		add_settings_field(
			'profile_visibility',
			__( 'Profile Visibility', 'wpmatch-free' ),
			array( $this, 'render_profile_visibility_field' ),
			'wpmatch-settings',
			'wpmatch_main'
		);

		add_settings_field(
			'new_user_approval',
			__( 'New User Approval', 'wpmatch-free' ),
			array( $this, 'render_approval_field' ),
			'wpmatch-settings',
			'wpmatch_main'
		);
	}

	/**
	 * Sanitize plugin settings before saving.
	 *
	 * @param array $input Raw input settings.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		$sanitized                       = array();
		$sanitized['profile_visibility'] = in_array( $input['profile_visibility'], array( 'public', 'members' ), true )
			? $input['profile_visibility']
			: 'public';
		$sanitized['new_user_approval']  = isset( $input['new_user_approval'] ) ? 'yes' : 'no';
		return $sanitized;
	}

	/**
	 * Render the profile visibility select field.
	 */
	public function render_profile_visibility_field() {
		$settings = get_option( 'wpmatch_settings' );
		?>
		<select name="wpmatch_settings[profile_visibility]">
			<option value="public" <?php selected( $settings['profile_visibility'] ?? 'public', 'public' ); ?>>
				<?php esc_html_e( 'Public', 'wpmatch-free' ); ?>
			</option>
			<option value="members" <?php selected( $settings['profile_visibility'] ?? 'public', 'members' ); ?>>
				<?php esc_html_e( 'Members Only', 'wpmatch-free' ); ?>
			</option>
		</select>
		<?php
	}

	/**
	 * Render the new user approval checkbox field.
	 */
	public function render_approval_field() {
		$settings = get_option( 'wpmatch_settings' );
		?>
		<label>
			<input type="checkbox" name="wpmatch_settings[new_user_approval]" value="1" 
				<?php checked( $settings['new_user_approval'] ?? 'no', 'yes' ); ?>>
			<?php esc_html_e( 'Require admin approval for new members', 'wpmatch-free' ); ?>
		</label>
		<?php
	}

	/**
	 * Render the settings section description.
	 */
	public function render_settings_section() {
		echo '<p>' . esc_html__( 'Configure core plugin settings', 'wpmatch-free' ) . '</p>';
	}

	/**
	 * Render the main plugin settings page.
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Show settings saved message.
		if ( isset( $_GET['settings-updated'] ) ) {
			add_settings_error(
				'wpmatch_messages',
				'wpmatch_message',
				__( 'Settings Saved', 'wpmatch-free' ),
				'updated'
			);
		}

		settings_errors( 'wpmatch_messages' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'WP Match Settings', 'wpmatch-free' ); ?></h1>
			<form method="post" action="options.php">
				<?php
				settings_fields( 'wpmatch_settings' );
				do_settings_sections( 'wpmatch-settings' );
				submit_button( __( 'Save Settings', 'wpmatch-free' ) );
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * Add settings link to plugin action links.
	 *
	 * @param array $links Plugin action links.
	 * @return array Modified links.
	 */
	public function add_plugin_action_links( $links ) {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			admin_url( 'admin.php?page=wpmatch-settings' ),
			__( 'Settings', 'wpmatch-free' )
		);
		array_unshift( $links, $settings_link );
		return $links;
	}

	/**
	 * Render demo content management page
	 *
	 * @since 1.0.0
	 */
	public function render_demo_page() {
		// Get demo statistics.
		$demo  = new WPMatch_Demo();
		$stats = $demo->get_demo_stats();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Demo Content Management', 'wpmatch-free' ); ?></h1>
			
			<div class="wpmatch-demo-manager">
				<!-- Demo Statistics -->
				<div class="demo-stats-section">
					<h2><?php esc_html_e( 'Demo Content Statistics', 'wpmatch-free' ); ?></h2>
					<div class="demo-stats-grid">
						<div class="stat-card">
							<div class="stat-number"><?php echo esc_html( $stats['total_demo_users'] ); ?></div>
							<div class="stat-label"><?php esc_html_e( 'Demo Users', 'wpmatch-free' ); ?></div>
						</div>
						<div class="stat-card">
							<div class="stat-number"><?php echo esc_html( $stats['users_with_profiles'] ); ?></div>
							<div class="stat-label"><?php esc_html_e( 'With Profiles', 'wpmatch-free' ); ?></div>
						</div>
						<div class="stat-card">
							<div class="stat-number"><?php echo esc_html( $stats['free_limit'] ); ?></div>
							<div class="stat-label"><?php esc_html_e( 'Free Limit', 'wpmatch-free' ); ?></div>
						</div>
						<div class="stat-card <?php echo $stats['can_create_more'] ? 'available' : 'limit-reached'; ?>">
							<div class="stat-number"><?php echo esc_html( $stats['free_limit'] - $stats['total_demo_users'] ); ?></div>
							<div class="stat-label"><?php esc_html_e( 'Remaining', 'wpmatch-free' ); ?></div>
						</div>
					</div>
				</div>

				<!-- Demo Actions -->
				<div class="demo-actions-section">
					<h2><?php esc_html_e( 'Demo Content Actions', 'wpmatch-free' ); ?></h2>
					
					<div class="demo-action-cards">
						<div class="action-card create-users">
							<h3><?php esc_html_e( 'Create Demo Users', 'wpmatch-free' ); ?></h3>
							<p><?php esc_html_e( 'Generate realistic demo users with complete profiles to test your dating site features and design.', 'wpmatch-free' ); ?></p>
							
							<div class="create-users-form">
								<label for="demo-user-count"><?php esc_html_e( 'Number of users to create:', 'wpmatch-free' ); ?></label>
								<select id="demo-user-count" name="demo_user_count">
									<option value="5">5 <?php esc_html_e( 'users', 'wpmatch-free' ); ?></option>
									<option value="10" selected>10 <?php esc_html_e( 'users', 'wpmatch-free' ); ?></option>
									<option value="15">15 <?php esc_html_e( 'users', 'wpmatch-free' ); ?></option>
									<option value="20">20 <?php esc_html_e( 'users', 'wpmatch-free' ); ?></option>
								</select>
								
								<button type="button" class="button button-primary" id="create-demo-users" <?php echo ! $stats['can_create_more'] ? 'disabled' : ''; ?>>
									<?php esc_html_e( 'Create Demo Users', 'wpmatch-free' ); ?>
								</button>
							</div>
							
							<?php if ( ! $stats['can_create_more'] ) : ?>
								<p class="demo-limit-notice">
									<?php esc_html_e( 'Free limit reached. Clean up existing demo users or upgrade for more.', 'wpmatch-free' ); ?>
								</p>
							<?php endif; ?>
						</div>

						<div class="action-card cleanup-users">
							<h3><?php esc_html_e( 'Clean Up Demo Content', 'wpmatch-free' ); ?></h3>
							<p><?php esc_html_e( 'Remove all demo users and their profile data. This action cannot be undone.', 'wpmatch-free' ); ?></p>
							
							<button type="button" class="button button-secondary" id="cleanup-demo-users" <?php echo 0 === $stats['total_demo_users'] ? 'disabled' : ''; ?>>
								<?php esc_html_e( 'Clean Up All Demo Users', 'wpmatch-free' ); ?>
							</button>
						</div>
					</div>
				</div>

				<!-- Premium Demo Packs -->
				<div class="demo-addons-section">
					<h2><?php esc_html_e( 'Premium Demo Content Packs', 'wpmatch-free' ); ?></h2>
					<div class="addon-packs">
						<div class="pack-card">
							<h4><?php esc_html_e( 'Extended Demo Pack', 'wpmatch-free' ); ?></h4>
							<p><?php esc_html_e( '100 additional diverse demo users with enhanced profiles', 'wpmatch-free' ); ?></p>
							<span class="pack-price"><?php esc_html_e( '$19.99', 'wpmatch-free' ); ?></span>
							<button class="button button-primary" disabled><?php esc_html_e( 'Coming Soon', 'wpmatch-free' ); ?></button>
						</div>
						<div class="pack-card">
							<h4><?php esc_html_e( 'Professional Demo Pack', 'wpmatch-free' ); ?></h4>
							<p><?php esc_html_e( '500 demo users + demo messages and interactions', 'wpmatch-free' ); ?></p>
							<span class="pack-price"><?php esc_html_e( '$49.99', 'wpmatch-free' ); ?></span>
							<button class="button button-primary" disabled><?php esc_html_e( 'Coming Soon', 'wpmatch-free' ); ?></button>
						</div>
						<div class="pack-card">
							<h4><?php esc_html_e( 'Enterprise Demo Pack', 'wpmatch-free' ); ?></h4>
							<p><?php esc_html_e( 'Unlimited demo users + custom profile generation', 'wpmatch-free' ); ?></p>
							<span class="pack-price"><?php esc_html_e( '$99.99', 'wpmatch-free' ); ?></span>
							<button class="button button-primary" disabled><?php esc_html_e( 'Coming Soon', 'wpmatch-free' ); ?></button>
						</div>
					</div>
				</div>

				<!-- Tips and Information -->
				<div class="demo-info-section">
					<h3><?php esc_html_e( 'Demo Content Tips', 'wpmatch-free' ); ?></h3>
					<ul>
						<li><?php esc_html_e( 'Demo users are created with realistic profiles and photos to showcase your site', 'wpmatch-free' ); ?></li>
						<li><?php esc_html_e( 'All demo users are marked as "demo" and can be easily identified and removed', 'wpmatch-free' ); ?></li>
						<li><?php esc_html_e( 'Demo content helps you test features, see design layouts, and show the site to clients', 'wpmatch-free' ); ?></li>
						<li><?php esc_html_e( 'Free version includes 20 demo users - upgrade for larger demo populations', 'wpmatch-free' ); ?></li>
					</ul>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get field groups
	 *
	 * @since 1.0.0
	 * @return array Field groups with labels.
	 */
	private function get_field_groups() {
		return array(
			'basic'        => __( 'Basic Identity', 'wpmatch-free' ),
			'location'     => __( 'Location & Lifestyle', 'wpmatch-free' ),
			'appearance'   => __( 'Appearance', 'wpmatch-free' ),
			'lifestyle'    => __( 'Lifestyle', 'wpmatch-free' ),
			'interests'    => __( 'Interests', 'wpmatch-free' ),
			'verification' => __( 'Verification', 'wpmatch-free' ),
		);
	}

	/**
	 * AJAX: Save field
	 *
	 * @since 1.0.0
	 */
	public function ajax_save_field() {
		check_ajax_referer( 'wpmatch_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		// Security check for required POST data.
		if ( empty( $_POST['field_key'] ) || empty( $_POST['field_label'] ) || empty( $_POST['field_type'] ) ) {
			wp_send_json_error( 'Required field data missing' );
		}

		$field_data = array(
			'field_key'   => sanitize_key( wp_unslash( $_POST['field_key'] ) ),
			'field_label' => sanitize_text_field( wp_unslash( $_POST['field_label'] ) ),
			'field_type'  => sanitize_text_field( wp_unslash( $_POST['field_type'] ) ),
			'field_group' => sanitize_text_field( wp_unslash( $_POST['field_group'] ?? 'basic' ) ),
			'is_required' => isset( $_POST['is_required'] ) ? 1 : 0,
			'searchable'  => isset( $_POST['searchable'] ) ? 1 : 0,
			'options'     => isset( $_POST['options'] ) ? wp_json_encode( array_map( 'sanitize_text_field', wp_unslash( $_POST['options'] ) ) ) : null,
		);

		global $wpdb;

		// Check if field_id is set before using it.
		if ( isset( $_POST['field_id'] ) && ! empty( $_POST['field_id'] ) ) {
			// Update existing field.
			$result = $wpdb->update(
				$wpdb->prefix . 'wpmatch_profile_fields',
				$field_data,
				array( 'field_id' => intval( $_POST['field_id'] ) )
			);
		} else {
			// Create new field.
			$max_order                   = $wpdb->get_var( "SELECT MAX(display_order) + 1 FROM {$wpdb->prefix}wpmatch_profile_fields" );
			$field_data['display_order'] = $max_order ? $max_order : 0;
			$result                      = $wpdb->insert( $wpdb->prefix . 'wpmatch_profile_fields', $field_data );
		}

		if ( false !== $result ) {
			wp_send_json_success( 'Field saved successfully' );
		} else {
			wp_send_json_error( 'Failed to save field' );
		}
	}

	/**
	 * AJAX: Delete field
	 *
	 * @since 1.0.0
	 */
	public function ajax_delete_field() {
		check_ajax_referer( 'wpmatch_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		// Validate field_id before usage and ensure nonce verification for form data.
		if ( ! isset( $_POST['field_id'] ) || empty( $_POST['field_id'] ) ) {
			wp_send_json_error( 'Missing field_id.' );
		}
		$field_id = intval( $_POST['field_id'] );

		global $wpdb;
		$result = $wpdb->delete(
			$wpdb->prefix . 'wpmatch_profile_fields',
			array( 'field_id' => $field_id ),
			array( '%d' )
		);

		if ( $result ) {
			wp_send_json_success( 'Field deleted successfully' );
		} else {
			wp_send_json_error( 'Failed to delete field' );
		}
	}

	/**
	 * AJAX: Reorder fields
	 *
	 * @since 1.0.0
	 */
	public function ajax_reorder_fields() {
		check_ajax_referer( 'wpmatch_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		if ( ! isset( $_POST['field_order'] ) || ! is_array( $_POST['field_order'] ) ) {
			wp_send_json_error( 'Invalid field order data' );
		}

		$field_order = array_map( 'intval', $_POST['field_order'] );

		global $wpdb;
		foreach ( $field_order as $order => $field_id ) {
			$wpdb->update(
				$wpdb->prefix . 'wpmatch_profile_fields',
				array( 'display_order' => $order ),
				array( 'field_id' => $field_id ),
				array( '%d' ),
				array( '%d' )
			);
		}

		wp_send_json_success( 'Field order updated' );
	}

	/**
	 * Render members management page
	 */
	public function render_members_page() {
		global $wpdb;
		$users = $wpdb->get_results( "SELECT ID, user_login, user_email, user_registered, display_name FROM {$wpdb->users} ORDER BY user_registered DESC LIMIT 100" );
		echo '<div class="wrap"><h1>' . esc_html__( 'Members Management', 'wpmatch-free' ) . '</h1>';
		echo '<table class="widefat fixed striped"><thead><tr>';
		echo '<th>' . esc_html__( 'ID', 'wpmatch-free' ) . '</th>';
		echo '<th>' . esc_html__( 'Username', 'wpmatch-free' ) . '</th>';
		echo '<th>' . esc_html__( 'Display Name', 'wpmatch-free' ) . '</th>';
		echo '<th>' . esc_html__( 'Email', 'wpmatch-free' ) . '</th>';
		echo '<th>' . esc_html__( 'Registered', 'wpmatch-free' ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $users as $user ) {
			echo '<tr>';
			echo '<td>' . esc_html( $user->ID ) . '</td>';
			echo '<td>' . esc_html( $user->user_login ) . '</td>';
			echo '<td>' . esc_html( $user->display_name ) . '</td>';
			echo '<td>' . esc_html( $user->user_email ) . '</td>';
			echo '<td>' . esc_html( $user->user_registered ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
		echo '<p>' . esc_html__( 'This page shows the 100 most recently registered members. More management features coming soon.', 'wpmatch-free' ) . '</p>';
		echo '</div>';
	}
}

// Initialize admin.
add_action(
	'plugins_loaded',
	function () {
		new WPMatch_Admin();
	}
);